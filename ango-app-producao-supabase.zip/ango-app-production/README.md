# Ango App

Aplicação Android nativa em Kotlin + Jetpack Compose, com identidade visual preta e dourada e integração Supabase preparada.

## Incluído
- Estrutura Android e navegação inferior.
- Ecrã inicial, categorias, exploração de anúncios.
- Fluxos iniciais de registo/login e publicação.
- Cliente REST Supabase para Auth e leitura/criação de anúncios.
- Esquema SQL com perfis, vendedores, anúncios, encomendas, itens, biblioteca digital, conversas, mensagens, avaliações, favoritos, denúncias, ledger, publicidade, subscrições e notificações.
- RLS inicial e buckets Storage.
- GitHub Actions para compilar APK debug.

## Estado real
Este é um alicerce de produção e uma primeira implementação funcional de autenticação/anúncios, não uma plataforma já auditada ou pronta para movimentar dinheiro. Carrinho, checkout, pagamentos, chat em tempo real, administração, campanhas, assinaturas, push notifications e downloads protegidos ainda exigem implementação de serviços e testes específicos. Não aceitar pagamentos reais até integrar um prestador e validar webhooks no servidor.

## Compilar
Executa `gradle :app:assembleDebug` com JDK 17 e Android SDK instalado, ou usa o workflow GitHub Actions.

## Supabase
Segue `CONFIGURACAO_SUPABASE.md` e executa `supabase/schema.sql`.
