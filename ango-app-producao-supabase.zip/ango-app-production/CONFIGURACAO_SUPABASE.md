# Configuração Supabase do Ango App

## 1. Criar o projeto
1. Cria um projeto em https://supabase.com/
2. Abre **SQL Editor** e executa todo o ficheiro `supabase/schema.sql`.
3. Em **Project Settings → API**, copia o Project URL e a chave `anon` / publishable.
4. Nunca copies a chave `service_role` para o Android, GitHub ou qualquer ficheiro público.

## 2. Ligar a aplicação
No GitHub, abre o repositório e cria o ficheiro `gradle.properties` na raiz (ou adiciona estas propriedades ao existente):

```properties
SUPABASE_URL=https://TEU-PROJETO.supabase.co
SUPABASE_ANON_KEY=TUA_CHAVE_PUBLICA_ANON
```

Para produção, recomenda-se guardar estes valores como GitHub Actions Secrets e passá-los ao Gradle durante a compilação. A chave anon é pública por desenho, mas a segurança depende das políticas RLS. A chave service_role é secreta e nunca deve estar no APK.

## 3. Armazenamento
O SQL cria os buckets `listing-images` e `digital-products`. Imagens podem ser públicas; ficheiros digitais são privados e só devem ser descarregados por utilizadores com direito de acesso. Antes de vender ficheiros digitais, implementar URLs assinados de curta duração e validação de entitlement no servidor.

## 4. Antes de aceitar dinheiro real
- Integrar um fornecedor de pagamentos disponível em Angola.
- Criar Edge Functions ou backend seguro para criar cobranças e validar webhooks.
- Só o servidor pode marcar encomendas como pagas, gerar direitos de download ou lançar créditos na carteira.
- Não confiar em comprovativos, parâmetros enviados pelo telemóvel ou estados alterados pelo cliente.
- Testar cancelamentos, reembolsos, duplicação de webhooks e reconciliação.

## 5. Preparação para produção
Configurar confirmação de e-mail, SMTP, recuperação de palavra-passe, limites de upload, cópias de segurança, monitorização, políticas de privacidade e termos de utilização. Fazer testes de segurança às políticas RLS antes de abrir ao público.
