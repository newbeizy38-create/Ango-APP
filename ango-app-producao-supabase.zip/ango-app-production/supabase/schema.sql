-- ANGO APP: schema inicial de produção para Supabase (PostgreSQL)
-- Executar no SQL Editor do projeto Supabase.
-- Nunca colocar a chave service_role na aplicação Android.

create extension if not exists pgcrypto;

do $$ begin
  create type public.account_role as enum ('buyer','seller','business','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.listing_type as enum ('physical','digital','service');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.listing_status as enum ('draft','pending','active','rejected','archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.order_status as enum ('pending','awaiting_payment','paid','processing','shipped','completed','cancelled','refunded','disputed');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text,
  avatar_url text,
  role public.account_role not null default 'buyer',
  province text,
  municipality text,
  commune text,
  neighborhood text,
  bio text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.seller_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  store_name text not null,
  description text,
  business_registration text,
  rating numeric(3,2) not null default 0,
  total_sales bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  parent_id uuid references public.categories(id),
  is_active boolean not null default true
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  title text not null check (char_length(title) between 3 and 120),
  description text not null default '',
  price_kz bigint not null check (price_kz >= 0),
  category text not null,
  listing_type public.listing_type not null default 'physical',
  status public.listing_status not null default 'pending',
  province text,
  municipality text,
  image_url text,
  digital_object_path text,
  stock_quantity integer check (stock_quantity is null or stock_quantity >= 0),
  license_terms text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id),
  seller_id uuid not null references public.profiles(id),
  status public.order_status not null default 'pending',
  subtotal_kz bigint not null check (subtotal_kz >= 0),
  delivery_fee_kz bigint not null default 0 check (delivery_fee_kz >= 0),
  platform_fee_kz bigint not null default 0 check (platform_fee_kz >= 0),
  total_kz bigint not null check (total_kz >= 0),
  delivery_address jsonb,
  payment_provider text,
  payment_reference text unique,
  payment_verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  listing_id uuid not null references public.listings(id),
  quantity integer not null check (quantity > 0),
  unit_price_kz bigint not null check (unit_price_kz >= 0),
  title_snapshot text not null
);

create table if not exists public.digital_entitlements (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id),
  listing_id uuid not null references public.listings(id),
  order_id uuid not null references public.orders(id),
  granted_at timestamptz not null default now(),
  unique (buyer_id, listing_id, order_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id),
  seller_id uuid not null references public.profiles(id),
  listing_id uuid references public.listings(id),
  created_at timestamptz not null default now(),
  unique (buyer_id, seller_id, listing_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null check (char_length(body) between 1 and 5000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  reviewer_id uuid not null references public.profiles(id),
  seller_id uuid not null references public.profiles(id),
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (order_id, reviewer_id)
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id),
  listing_id uuid references public.listings(id),
  reported_user_id uuid references public.profiles(id),
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  entry_type text not null check (entry_type in ('credit','debit','fee','refund','adjustment')),
  amount_kz bigint not null check (amount_kz > 0),
  reference text,
  description text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  title text not null,
  budget_kz bigint not null check (budget_kz >= 0),
  status text not null default 'draft',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  plan_code text not null,
  status text not null default 'pending',
  starts_at timestamptz,
  ends_at timestamptz,
  provider_reference text,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.seller_profiles enable row level security;
alter table public.categories enable row level security;
alter table public.listings enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.digital_entitlements enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.favorites enable row level security;
alter table public.reports enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.subscriptions enable row level security;
alter table public.notifications enable row level security;

create policy "profiles are visible to signed-in users" on public.profiles for select to authenticated using (true);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "seller profile public read" on public.seller_profiles for select to anon, authenticated using (true);
create policy "seller manages own profile" on public.seller_profiles for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "active categories public" on public.categories for select to anon, authenticated using (is_active);
create policy "active listings public read" on public.listings for select to anon, authenticated using (status = 'active' or seller_id = auth.uid());
create policy "seller creates own listings" on public.listings for insert to authenticated with check (seller_id = auth.uid() and status in ('draft','pending'));
create policy "seller updates own pending listings" on public.listings for update to authenticated using (seller_id = auth.uid() and status in ('draft','pending','rejected')) with check (seller_id = auth.uid() and status in ('draft','pending'));
create policy "buyer sees own orders" on public.orders for select to authenticated using (buyer_id = auth.uid() or seller_id = auth.uid());
create policy "buyer creates own pending orders" on public.orders for insert to authenticated with check (buyer_id = auth.uid() and status = 'pending' and payment_verified_at is null);
create policy "order participants read items" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id = order_id and (o.buyer_id = auth.uid() or o.seller_id = auth.uid())));
create policy "buyer sees own entitlements" on public.digital_entitlements for select to authenticated using (buyer_id = auth.uid());
create policy "participants read conversations" on public.conversations for select to authenticated using (buyer_id = auth.uid() or seller_id = auth.uid());
create policy "buyer starts conversation" on public.conversations for insert to authenticated with check (buyer_id = auth.uid());
create policy "participants read messages" on public.messages for select to authenticated using (exists(select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())));
create policy "participants send messages" on public.messages for insert to authenticated with check (sender_id = auth.uid() and exists(select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())));
create policy "reviews public read" on public.reviews for select to anon, authenticated using (true);
create policy "reviewer creates own review" on public.reviews for insert to authenticated with check (reviewer_id = auth.uid());
create policy "users manage own favorites" on public.favorites for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "users create reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "reporter reads own reports" on public.reports for select to authenticated using (reporter_id = auth.uid());
create policy "users read own wallet ledger" on public.wallet_ledger for select to authenticated using (user_id = auth.uid());
create policy "owners manage own campaigns" on public.ad_campaigns for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "users read own subscriptions" on public.subscriptions for select to authenticated using (user_id = auth.uid());
create policy "users read own notifications" on public.notifications for select to authenticated using (user_id = auth.uid());

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('listing-images','listing-images',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('digital-products','digital-products',false,104857600,array['application/pdf','application/zip','audio/mpeg','video/mp4'])
on conflict (id) do nothing;

create policy "public can view listing images" on storage.objects for select to anon, authenticated using (bucket_id = 'listing-images');
create policy "signed-in users upload listing images" on storage.objects for insert to authenticated with check (bucket_id = 'listing-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "users update own listing images" on storage.objects for update to authenticated using (bucket_id = 'listing-images' and owner = auth.uid());
create policy "buyers access digital files with entitlement" on storage.objects for select to authenticated using (
  bucket_id = 'digital-products' and exists (
    select 1 from public.digital_entitlements e
    join public.listings l on l.id = e.listing_id
    where e.buyer_id = auth.uid() and l.digital_object_path = name
  )
);
create policy "sellers upload digital files to own folder" on storage.objects for insert to authenticated with check (bucket_id = 'digital-products' and (storage.foldername(name))[1] = auth.uid()::text);

-- Admin actions should be performed only by trusted server-side functions using service_role.
-- Never let the Android client mark orders as paid or credit wallet balances.
