# Próximos passos obrigatórios antes do lançamento público

1. Criar projeto Supabase e executar `supabase/schema.sql`.
2. Adicionar `SUPABASE_URL` e `SUPABASE_ANON_KEY` como GitHub Actions Secrets.
3. Implementar persistência segura de sessão (DataStore/refresh token) e ecrãs completos de perfil.
4. Implementar carrinho e criação de encomenda com RPC/Edge Function que valide preços no servidor.
5. Integrar pagamentos angolanos com webhooks verificados no backend.
6. Implementar mensagens em tempo real, notificações push e uploads com limites e validação MIME.
7. Implementar URLs assinados para downloads digitais e validar direitos de acesso no servidor.
8. Implementar painel Admin em aplicação web protegida, não expor privilégios administrativos no APK.
9. Testar RLS com utilizadores de papéis diferentes, testes de abuso, privacidade e recuperação de conta.
10. Fazer testes em dispositivos Android reais e preparar assinatura de release, política de privacidade e termos.

A aplicação nunca deve incluir a chave `service_role`.
