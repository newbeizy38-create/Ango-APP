package ao.ango.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ao.ango.app.data.SupabaseApi
import kotlinx.coroutines.launch
import org.json.JSONArray

private val Ink = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6AD45)
private val Soft = Color(0xFFE8E2D4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AngoApp() }
    }
}

@Composable
private fun AngoApp() {
    val api = remember { SupabaseApi() }
    var tab by remember { mutableStateOf("Início") }
    var message by remember { mutableStateOf("") }
    var listings by remember { mutableStateOf(JSONArray()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAuth by remember { mutableStateOf(false) }
    var showPublish by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Ink, background = Ink, surface = Panel,
        onBackground = Soft, onSurface = Soft, secondary = Gold
    )) {
        LaunchedEffect(refresh) {
            if (api.configured) runCatching { api.listings() }
                .onSuccess { listings = it }
                .onFailure { message = it.message ?: "Falha ao carregar anúncios." }
        }
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    val items = listOf("Início", "Explorar", "Publicar", "Mensagens", "Perfil")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.AddCircle, Icons.Default.Chat, Icons.Default.Person)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = {
                                tab = label
                                if (label == "Publicar") showPublish = true
                                if (label == "Perfil") showAuth = true
                            },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Color(0xFF3A2E15), unselectedIconColor = Soft
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Início" -> HomeScreen(
                        configured = api.configured,
                        listings = listings,
                        message = message,
                        onRefresh = { refresh++ },
                        onExplore = { tab = "Explorar" }
                    )
                    "Explorar" -> ExploreScreen(listings)
                    "Mensagens" -> FeatureScreen("Mensagens", "Conversa entre compradores e vendedores. A ativação depende das tabelas e políticas Supabase.")
                    "Perfil" -> ProfileScreen(api.configured, onAuth = { showAuth = true })
                    else -> HomeScreen(api.configured, listings, message, { refresh++ }, { tab = "Explorar" })
                }
            }
        }

        if (showAuth) AuthDialog(api, onDismiss = { showAuth = false }) { message = it }
        if (showPublish) PublishDialog(api, onDismiss = { showPublish = false }) {
            message = it
            refresh++
        }
    }
}

@Composable
private fun TopBrand() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text("A", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("ANGO APP", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 2.sp)
            Text("Compre • Venda • Conquiste", color = Soft.copy(alpha = .65f), fontSize = 10.sp)
        }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.NotificationsNone, null, tint = Gold)
    }
}

@Composable
private fun HomeScreen(
    configured: Boolean, listings: JSONArray, message: String,
    onRefresh: () -> Unit, onExplore: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopBrand()
        LazyColumn(contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Column(Modifier.padding(horizontal = 18.dp)) {
                    Text("O mercado angolano,\nnum só lugar.", color = Soft, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Encontra produtos, serviços e oportunidades perto de ti.", color = Soft.copy(alpha = .65f), fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = "", onValueChange = {}, readOnly = true,
                        placeholder = { Text("Pesquisar produtos e serviços") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = { Icon(Icons.Default.Tune, null) },
                        modifier = Modifier.fillMaxWidth().clickable { onExplore() },
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Gold, unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Soft, unfocusedTextColor = Soft
                        )
                    )
                }
            }
            item {
                Column(Modifier.padding(horizontal = 18.dp)) {
                    Box(Modifier.fillMaxWidth().background(
                        androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF3B2D12), Color(0xFF17130B))),
                        RoundedCornerShape(20.dp)).padding(18.dp)) {
                        Column {
                            Text("ANGOLA COMPRA E VENDE", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("A tua próxima oportunidade começa aqui.", color = Soft, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onExplore, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                Text("Explorar agora", color = Ink, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Text("Explora por categoria", color = Soft, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 18.dp))
                CategoryGrid()
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Anúncios recentes", color = Soft, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.weight(1f))
                    Text("Atualizar", color = Gold, modifier = Modifier.clickable { onRefresh() })
                }
            }
            if (!configured) {
                item { InfoCard("Supabase por ligar", "A aplicação está pronta para receber o URL e a chave pública anon do teu projeto. Consulta CONFIGURACAO_SUPABASE.md.") }
            } else if (listings.length() == 0) {
                item { InfoCard("Ainda sem anúncios", "Quando os vendedores publicarem anúncios aprovados, eles aparecerão aqui.") }
            } else {
                items((0 until listings.length()).toList()) { index ->
                    val obj = listings.optJSONObject(index) ?: return@items
                    ListingCard(obj.optString("title"), obj.optString("description"), obj.optString("category"), obj.optLong("price_kz"))
                }
            }
            if (message.isNotBlank()) item { Text(message, color = Gold, modifier = Modifier.padding(horizontal = 18.dp)) }
        }
    }
}

@Composable
private fun CategoryGrid() {
    val categories = listOf(
        "Produtos físicos" to Icons.Default.ShoppingBag,
        "E-books e cursos" to Icons.Default.MenuBook,
        "Tecnologia" to Icons.Default.Devices,
        "Moda" to Icons.Default.Checkroom,
        "Serviços" to Icons.Default.Handyman,
        "Música e media" to Icons.Default.MusicNote,
        "Imobiliário" to Icons.Default.HomeWork,
        "Veículos" to Icons.Default.DirectionsCar
    )
    Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        categories.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                row.forEach { (name, icon) ->
                    Column(
                        Modifier.weight(1f).background(Panel, RoundedCornerShape(14.dp)).padding(vertical = 13.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(icon, null, tint = Gold, modifier = Modifier.size(23.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(name, color = Soft, fontSize = 9.sp, maxLines = 2)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun ListingCard(title: String, description: String, category: String, price: Long) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(category.uppercase(), color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Soft, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (description.isNotBlank()) Text(description, color = Soft.copy(alpha = .65f), fontSize = 12.sp, maxLines = 2)
        Text(String.format("%,d Kz", price).replace(",", " "), color = Gold, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ExploreScreen(listings: JSONArray) {
    Column(Modifier.fillMaxSize()) {
        TopBrand()
        Text("Explorar", color = Soft, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp))
        Text("Descobre produtos e serviços disponíveis.", color = Soft.copy(alpha = .6f), modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            if (listings.length() == 0) item { InfoCard("Sem resultados", "Os anúncios ativos serão apresentados aqui quando o Supabase estiver configurado.") }
            items((0 until listings.length()).toList()) { i ->
                val o = listings.optJSONObject(i) ?: return@items
                ListingCard(o.optString("title"), o.optString("description"), o.optString("category"), o.optLong("price_kz"))
            }
        }
    }
}

@Composable
private fun ProfileScreen(configured: Boolean, onAuth: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBrand()
        Text("A tua conta", color = Soft, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp))
        InfoCard("Comprador, vendedor ou empresa", "Cria a tua conta para gerir perfil, anúncios, encomendas e atividade.")
        Spacer(Modifier.height(14.dp))
        Button(onClick = onAuth, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
            Text("Entrar ou criar conta", color = Ink, fontWeight = FontWeight.Bold)
        }
        Text(if (configured) "Backend Supabase configurado" else "Backend ainda não configurado", color = Gold, modifier = Modifier.padding(18.dp))
    }
}

@Composable
private fun FeatureScreen(title: String, description: String) {
    Column(Modifier.fillMaxSize()) {
        TopBrand()
        Text(title, color = Soft, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp))
        InfoCard(title, description)
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
        Text(title, color = Gold, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Soft.copy(alpha = .75f), fontSize = 13.sp)
    }
}

@Composable
private fun AuthDialog(api: SupabaseApi, onDismiss: () -> Unit, onMessage: (String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Acede à tua conta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(email, { email = it }, label = { Text("E-mail") }, singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("Palavra-passe") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                if (!api.configured) Text("Configura primeiro o Supabase no ficheiro de configuração.", color = Gold, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Column {
                TextButton(enabled = !busy && api.configured, onClick = {
                    if (email.isBlank() || password.length < 8) { error = "Indica um e-mail e uma palavra-passe com pelo menos 8 caracteres."; return@TextButton }
                    busy = true
                    scope.launch { runCatching { api.signIn(email, password) }.onSuccess { onMessage(it); onDismiss() }.onFailure { error = it.message ?: "Erro"; }.also { busy = false } }
                }) { Text("Entrar") }
                TextButton(enabled = !busy && api.configured, onClick = {
                    if (email.isBlank() || password.length < 8) { error = "Indica um e-mail e uma palavra-passe com pelo menos 8 caracteres."; return@TextButton }
                    busy = true
                    scope.launch { runCatching { api.signUp(email, password) }.onSuccess { onMessage(it); onDismiss() }.onFailure { error = it.message ?: "Erro" }.also { busy = false } }
                }) { Text("Criar conta") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
private fun PublishDialog(api: SupabaseApi, onDismiss: () -> Unit, onMessage: (String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Produtos") }
    var type by remember { mutableStateOf("physical") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Publicar anúncio") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Descrição") })
                OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Preço em Kz") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tipo:", color = Soft)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { type = if (type == "physical") "digital" else "physical" }) {
                        Text(if (type == "physical") "Físico (tocar para Digital)" else "Digital (tocar para Físico)")
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val amount = price.toLongOrNull()
                if (title.isBlank() || amount == null || amount <= 0) { error = "Preenche título e preço válido."; return@TextButton }
                busy = true
                scope.launch { runCatching { api.createListing(title, description, amount, category, type) }
                    .onSuccess { onMessage(it); onDismiss() }
                    .onFailure { error = it.message ?: "Não foi possível publicar." }
                    .also { busy = false } }
            }) { Text("Enviar para revisão") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
