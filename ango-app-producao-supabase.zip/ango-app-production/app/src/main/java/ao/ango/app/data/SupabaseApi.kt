package ao.ango.app.data

import ao.ango.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Supabase REST/Auth client. Only the public anon key belongs in the Android app.
 * NEVER put a service_role key in this project.
 */
class SupabaseApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private var accessToken: String? = null

    val configured: Boolean
        get() = BuildConfig.SUPABASE_URL.startsWith("https://") &&
            BuildConfig.SUPABASE_ANON_KEY.isNotBlank()

    private fun base(path: String) = BuildConfig.SUPABASE_URL.trimEnd('/') + path

    private fun request(path: String, method: String, body: String? = null, auth: Boolean = true): Request {
        val builder = Request.Builder()
            .url(base(path))
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY)
            .header("Accept", "application/json")
        if (auth) accessToken?.let { builder.header("Authorization", "Bearer $it") }
        else builder.header("Authorization", "Bearer ${BuildConfig.SUPABASE_ANON_KEY}")
        when (method) {
            "POST" -> builder.post((body ?: "{}").toRequestBody(jsonType))
            "PATCH" -> builder.patch((body ?: "{}").toRequestBody(jsonType))
            "DELETE" -> builder.delete()
            else -> builder.get()
        }
        return builder.build()
    }

    private suspend fun execute(req: Request): String = withContext(Dispatchers.IO) {
        client.newCall(req).execute().use { response ->
            val payload = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Supabase ${response.code}: $payload")
            payload
        }
    }

    suspend fun signUp(email: String, password: String): String {
        check(configured) { "Configura primeiro a ligação Supabase." }
        val payload = execute(request("/auth/v1/signup", "POST",
            JSONObject().put("email", email).put("password", password).toString(), auth = false))
        val obj = JSONObject(payload)
        accessToken = obj.optString("access_token").takeIf { it.isNotBlank() }
        return if (accessToken == null) "Conta criada. Confirma o e-mail e inicia sessão." else "Conta criada com sucesso."
    }

    suspend fun signIn(email: String, password: String): String {
        check(configured) { "Configura primeiro a ligação Supabase." }
        val payload = execute(request("/auth/v1/token?grant_type=password", "POST",
            JSONObject().put("email", email).put("password", password).toString(), auth = false))
        accessToken = JSONObject(payload).optString("access_token")
        return "Sessão iniciada."
    }

    suspend fun listings(): JSONArray {
        check(configured) { "Supabase ainda não configurado." }
        val payload = execute(request(
            "/rest/v1/listings?select=id,title,description,price_kz,category,listing_type,city,image_url,status&status=eq.active&order=created_at.desc&limit=50",
            "GET"
        ))
        return JSONArray(payload)
    }

    suspend fun createListing(title: String, description: String, priceKz: Long, category: String, type: String): String {
        check(configured) { "Supabase ainda não configurado." }
        check(!accessToken.isNullOrBlank()) { "Inicia sessão antes de publicar." }
        val body = JSONObject()
            .put("title", title)
            .put("description", description)
            .put("price_kz", priceKz)
            .put("category", category)
            .put("listing_type", type)
            .put("status", "pending")
        execute(request("/rest/v1/listings", "POST", body.toString())
            .newBuilder().header("Prefer", "return=minimal").build())
        return "Anúncio enviado para moderação."
    }

    fun clearSession() { accessToken = null }
}
